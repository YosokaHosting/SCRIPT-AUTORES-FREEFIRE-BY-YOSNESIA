<div align="center">
<img src="https://i.ibb.co/8zqD0Nx/IMG-20220810-WA0169.jpg" alt="YosokaCodeX" width="300" />

</p>
<h1 align="center">YOSOKA HOST</h1>

>
>
>
</div>
<p align="center">
  <a href="https://github.com/YosokaHosting"><img title="GitHub" src="https://img.shields.io/badge/Github-ramlaidi.svg?style=for-the-badge&logo=github" /></a>
  <a href="httts://instagram.com/yosoka_hosting"><img title="Instagram " src="https://img.shields.io/badge/Instagram-yosoka.svg?style=for-the-badge&logo=instagram" /></a>
  <a href="https://youtube.com/channel/UCh6zcsGjETF83ocmz4gvCHg"><img title="Youtube" src="https://img.shields.io/badge/Youtube-YosokaNesia.svg?style=for-the-badge&logo=youtube" /></a>
  <h4 align="center">
  <a
  <a href="https://wa.me/6285891634201">Klik disini untuk WhatsApp Yosoka </a>
</h4>
</p>

# Ambil Session Disini

> Buka [ Linknya Disini ](https://replit.com/@zeeoneofc/Session-Md?lita=1&outputonly=1#.replit) 
> Untuk Tutorialnya Liat Dan Subscribe [ Here ](https://youtube.com/channel/UCZoVmApPxtLYgUWwBD4nbCw) 

### Preview bot
------------------
- [x] Welcome <details><summary>Screenshot</summary><img src="https://telegra.ph/file/b3b7dff3e285c84442c3c.jpg"></details>
- [x] Reply bot <details><summary>Screenshot</summary><img src="https://telegra.ph/file/98c48528bd962f279ea7e.jpg"></details>
- [x] Menu  <details><summary>Screenshot</summary><img src="https://telegra.ph/file/dc3565c53a09154ef745e.jpg"></details>
------------------

# Run On Heroku

WhatsApp Bot Multi Device

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/ramlaidi/IrsanBotz)


# Heroku Buildpack

| BuildPack | LINK |
|--------|--------|
| **FFMPEG** |[HERE](https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest) |
| **IMAGEMAGICK** | [HERE](https://github.com/mcollina/heroku-buildpack-imagemagick.git) |
| **Node.js**     | heroku/nodejs|

# Creator Bot
 [![Ilman](https://github.com/ilmanhdyt.png?size=200)](https://github.com/ilmanhdyt) | [![GEMPY](https://github.com/GempyTon.png?size=200)](https://github.com/GempyTon) 
----|----
[Ilman](https://github.com/ilmanhdyt) | [GEMPY](https://github.com/GempyTon)
 Author | Creator
 
### SAN Statistics

[![ramlaidi GitHub Stats](https://github-readme-stats.vercel.app/api?username=ramlaidi&show_icons=true&hide=issues&theme=radical)](https://github-readme-stats.vercel.app)
[![ramlaidi Top Languages](https://github-readme-stats.vercel.app/api/top-langs?username=ramlaidi&layout=compact&theme=radical)](https://github-readme-stats.vercel.app)

# Thanks to
 [![Nurutomo](https://github.com/Nurutomo.png?size=200)](https://github.com/Nurutomo) | [![Ariffb](https://github.com/ariffb25.png?size=200)](https://github.com/ariffb25) | [![F](https://github.com/Paquito1923.png?size=200)](https://github.com/Paquito1923)
----|----|----
[Nurutomo](https://github.com/Nurutomo) | [Ariffb](https://github.com/ariffb25) | [Elyas](https://github.com/Paquito1923)
 Helpfully | Suhu? | Friends

---------

## Request Fitur To
[`Creator Here`](https://wa.me/6287898307350?text=Banh+req+fitur) 
